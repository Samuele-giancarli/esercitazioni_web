const parola = "appello";
let codificata = "a--+--o";


function replaceAt(string, index, replace) {
  return string.substring(0, index) + replace + string.substring(index + 1);
}

